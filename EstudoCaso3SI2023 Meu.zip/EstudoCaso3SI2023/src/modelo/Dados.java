/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author tulio
 */
public class Dados {
    
    public static List<Cidade> listaCidade = new ArrayList<>();
    public static List<Funcionario> listaFuncionario = new ArrayList<>();
    
}
